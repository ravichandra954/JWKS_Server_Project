from flask import Flask, jsonify, request
import jwt
import datetime
from jwks_utils import generate_key_pair, get_valid_keys, KEY_STORE

app = Flask(__name__)

@app.route('/.well-known/jwks.json', methods=['GET'])
def jwks():
    return jsonify(get_valid_keys())

@app.route('/auth', methods=['POST'])
def auth():
    expired = request.args.get('expired', False)
    kid = list(KEY_STORE.keys())[0]  # Use the first key for simplicity
    key_data = KEY_STORE[kid]

    if expired:
        expiry_time = key_data['expiry'] - datetime.timedelta(hours=2)
    else:
        expiry_time = datetime.datetime.utcnow() + datetime.timedelta(minutes=30)

    token = jwt.encode(
        {"sub": "user123", "exp": expiry_time, "kid": kid},
        key_data["private_key"],
        algorithm="RS256"
    )

    return jsonify({"token": token})

if __name__ == '__main__':
    generate_key_pair()
    app.run(host='0.0.0.0', port=5000)
