import jwt
import datetime
import uuid
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization

KEY_STORE = {}

def generate_key_pair():
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    public_key = private_key.public_key()

    kid = str(uuid.uuid4())
    expiry = datetime.datetime.utcnow() + datetime.timedelta(hours=1)

    private_key_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )

    public_key_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )

    KEY_STORE[kid] = {
        "private_key": private_key_pem,
        "public_key": public_key_pem,
        "expiry": expiry
    }

    return kid, public_key_pem, expiry

def get_valid_keys():
    valid_keys = []
    now = datetime.datetime.utcnow()
    for kid, key_data in KEY_STORE.items():
        if key_data["expiry"] > now:
            valid_keys.append({
                "kid": kid,
                "kty": "RSA",
                "use": "sig",
                "alg": "RS256",
                "n": key_data["public_key"].decode('utf-8')
            })
    return {"keys": valid_keys}
