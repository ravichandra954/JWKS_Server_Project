import pytest
from app import app
from jwks_utils import generate_key_pair

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def setup_module(module):
    """Generate keys before tests run."""
    generate_key_pair()

def test_jwks(client):
    """Test JWKS endpoint."""
    response = client.get('/.well-known/jwks.json')
    assert response.status_code == 200
    assert "keys" in response.get_json()

def test_auth(client):
    """Test Auth endpoint."""
    response = client.post('/auth')
    assert response.status_code == 200
    token = response.get_json()['token']
    assert token
