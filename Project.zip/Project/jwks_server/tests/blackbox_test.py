import requests

BASE_URL = "http://localhost:5000"

def test_blackbox():
    print("Fetching JWKS...")
    jwks_response = requests.get(f"{BASE_URL}/.well-known/jwks.json")
    print("JWKS Response:", jwks_response.json())

    print("Requesting Auth Token...")
    auth_response = requests.post(f"{BASE_URL}/auth")
    print("Auth Token:", auth_response.json())

if __name__ == "__main__":
    test_blackbox()
